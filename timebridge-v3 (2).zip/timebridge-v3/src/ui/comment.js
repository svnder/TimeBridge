// comment.js
import githubAuth from "../auth/githubAuth.js";
import { loadedTogglEntries } from "../ui/togglEntries.js"; // <– nimeline import

/* abifunktsioonid ---------------------------------------------------*/
const prettyDur = (sec) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return h ? `${h} t ${m} min` : `${m} min`;
};

const buildCommentBody = (entries) => {
    const bodyLines = entries.map(
        (e) => `- **${e.description || "(ilma nimeta)"}** — ${prettyDur(Math.abs(e.duration))}`
    );
    const totalSec = entries.reduce((s, e) => s + Math.abs(e.duration), 0);
    bodyLines.push(`\n**Kokku:** ${prettyDur(totalSec)}`);
    return bodyLines.join("\n");
};

const postIssueComment = async (repo, number, body, token) => {
    const r = await fetch(`https://api.github.com/repos/${repo}/issues/${number}/comments`, {
        method: "POST",
        headers: {
            Authorization: `token ${token}`,
            Accept: "application/vnd.github+json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ body }),
    });
    if (!r.ok) {
        const err = await r.json();
        console.log(">>> GitHub Token:", githubAuth.githubToken);
        throw new Error(`GitHub API error: ${err.message}`);
    } else if (r.status === 204) {
        return;
    }
    return r.json();
};

/* PEAMINE FUNKTSIOON -----------------------------------------------*/
const addTogglComment = async () => {
    const status = document.getElementById("commentStatusText");
    status.textContent = "";

    const repo = document.getElementById("repoSelect")?.value;
    const issue = document.getElementById("issueSelect")?.value;
    const checks = document.querySelectorAll(".entriesCheck:checked");

    if (!repo || !issue) {
        status.textContent = "⚠️ Vali repo ja issue!";
        return;
    }
    if (checks.length === 0) {
        status.textContent = "⚠️ Vali vähemalt üks Toggl kirje!";
        return;
    }

    /* võta kirjed, mille kastid märgitud */
    const entries = [...checks]
        .map(cb => loadedTogglEntries[Number(cb.dataset.entryIndex)])
        .filter(Boolean);              // juhuks kui midagi on vahepeal muutunud

    const body = buildCommentBody(entries);
    const token = await githubAuth.getGithubToken();

    try {
        await postIssueComment(repo, issue, body, token);
        status.textContent = "✅ Kommenteerimine õnnestus!";
    } catch (err) {
        console.error("EBAÕNNESTUS", err);
        status.textContent = `❌ ${err.message}`;
    }
};

export default addTogglComment;
