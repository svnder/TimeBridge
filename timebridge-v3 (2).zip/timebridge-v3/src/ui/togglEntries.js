// ui/togglEntries.js
import togglApi from "../api/toggl.js";

/* --- avalik vahemälu --------------------------------------------- */
export let loadedTogglEntries = [];      // täidetakse showTogglEntries() sees

/* ms → hh:mm -------------------------------------------------------- */
const toHM = (ms) => {
    const m = Math.floor(ms / 60000);
    const h = String(Math.floor(m / 60)).padStart(2, "0");
    return `${h}:${String(m % 60).padStart(2, "0")}`;
};

/* ------------------------------------------------------------------
   1) projektirippmenüü loomine + täitmine
------------------------------------------------------------------ */
export async function loadProjectSelector() {
    const box = document.getElementById("togglEntries");
    if (!box) { console.error("Toggl entries container not found"); return; }

    /* leia olemasolev <select> või loo uus */
    let sel = document.getElementById("projectSelect");
    if (!sel) {
        sel = document.createElement("select");
        sel.id = "projectSelect";
        sel.className = "w-full mb-2";
        box.parentNode.insertBefore(sel, box);
    }

    /* lae projektid */
    sel.disabled = true;
    sel.innerHTML = "<option>⏳ Laen projekte…</option>";

    try {
        const projects = await togglApi.fetchProjects();       // [{id,name}, …]
        sel.innerHTML =
            '<option disabled selected value="">— vali projekt —</option>' +
            projects.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
        sel.disabled = false;
    } catch (e) {
        sel.innerHTML = '<option disabled>⚠️ Projektide laadimine ebaõnnestus</option>';
        console.error("Project load error", e);
    }

    sel.addEventListener("change", () =>
        showTogglEntries(Number(sel.value) || null)
    );
}

/* ------------------------------------------------------------------
   2) kirjete kuvamine (kui pid == null ⇒ näita kõiki)
------------------------------------------------------------------ */
export async function showTogglEntries(pid = null) {
    const box = document.getElementById("togglEntries");
    if (!box) { console.error("Toggl entries container not found"); return; }

    box.textContent = "⏳ Laen Toggl kirjeid…";

    try {
        /* projektide nimed map-i (kui 403, jätame tühjaks) */
        const projs = await togglApi.fetchProjects().catch(() => []);
        const pNames = Object.fromEntries(projs.map(p => [p.id, p.name]));

        /* viimase 7 päeva kirjed */
        loadedTogglEntries = await togglApi.fetchTogglEntries();     // <– VAJALIK
        const entries = pid
            ? loadedTogglEntries.filter(e => e.pid === pid)
            : loadedTogglEntries;

        if (!entries.length) {
            box.textContent = "— valitud projektis kirjeid pole —";
            return;
        }

        /* render */
        box.innerHTML = entries.map((e, idx) => `
        <label class="flex gap-2 items-start">
          <input type="checkbox"
                 class="entriesCheck"
                 data-entry-index="${idx}">
          <span>
            <strong>${e.description || "(ilma nimeta)"}</strong>
            — ${toHM(Math.abs(e.duration) * 1000)} h<br>
            <small>${pNames[e.pid] || "-"}</small>
          </span>
        </label>
    `).join("<hr>");
    } catch (e) {
        console.error("Error loading Toggl entries", e);
        box.textContent = `❌ Viga: ${e.response?.status || ""} ${e.message}`;
    }
}

export default { loadProjectSelector, showTogglEntries, loadedTogglEntries };
