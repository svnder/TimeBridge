import axios from 'axios';
import togglAuth from '../auth/togglAuth.js';

const token = togglAuth?.togglToken?.trim();
if (!token) console.warn('⚠️ Toggl API-token puudub!');

const api = axios.create({
    baseURL: 'https://api.track.toggl.com/api/v9',
    auth: token ? { username: token, password: 'api_token' } : undefined,
    responseType: 'json',
});

// ————————————————————————————————————————————————
export const getTogglUser = () => api.get('/me').then(r => r.data);

export const fetchTogglEntries = (    // ⇐ võimalus anda start/end
    startISO = new Date(Date.now() - 7 * 864e5).toISOString(),
    endISO = new Date().toISOString(),
) =>
    api.get('/me/time_entries', { params: { start_date: startISO, end_date: endISO } })
        .then(r => r.data);


export const fetchProjects = () => api.get('/me/projects').then(r => r.data);

export default { getTogglUser, fetchTogglEntries, fetchProjects };
