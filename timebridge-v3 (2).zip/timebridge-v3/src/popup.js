import togglAPI from './api/toggl';
import togglAUTH from './auth/togglAuth';
import githubAuth from './auth/githubAuth';
import checkLogins from './auth/checkLogins';
import githubRepoIssueUI from './ui/githubRepoIssueUI';
import togglEntries from './ui/togglEntries';
import addTogglComment from './ui/comment';

document.addEventListener('DOMContentLoaded', async () => {

    /* 1) Toggl – projektid + kirjed (cache või live) */
    await togglEntries.loadProjectSelector();   // täidab <select>
    togglEntries.showTogglEntries();            // kuvab nimekirja
    /* 2) GitHubi asjad */
    githubRepoIssueUI.loadRepos();
    githubRepoIssueUI.loadIssues();
    document
        .getElementById('addTogglCommentButton')
        .addEventListener('click', addTogglComment);

    /* 3) login-kontrollid */
    togglAUTH.togglLogin();
    githubAuth.githubLogin();
    checkLogins.checkBothLogins();
});
