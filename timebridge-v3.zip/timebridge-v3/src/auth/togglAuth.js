import { fetchTogglEntries } from '../api/toggl.js';
import { checkBothLogins } from './githubAuth.js';
import { showTogglEntries } from '../ui/togglEntries.js';
import { setLoaderVisible } from '../ui/status.js';

let loginTabId = null;
let loginCheckInterval = null;
export let togglLoggedIn = false;
export let loadedTogglEntries = [];

export function initTogglLogin() {
    const loginButton = document.getElementById('loginButton');
    const togglStatusText = document.getElementById('togglStatusText');

    loginButton.addEventListener('click', () => {
        browser.tabs.create({ url: "https://track.toggl.com/login" }).then((tab) => {
            loginTabId = tab.id;
            togglStatusText.textContent = "Login Togglisse...";
            loginCheckInterval = setInterval(() => {
                checkTogglLogin(true);
            }, 3000);
        });
    });
}

export function checkTogglLogin(autoClose = false) {
    const togglStatusText = document.getElementById('togglStatusText');
    setLoaderVisible(true);

    fetchTogglEntries()
        .then(response => {
            if (response.status === 200) {
                togglLoggedIn = true;
                loadedTogglEntries = response.data;

                localStorage.setItem('togglStatus', "✅ Toggl login õnnestus!");
                setLoaderVisible(false);
                showTogglEntries(loadedTogglEntries); // UI update

                if (autoClose && loginTabId !== null) {
                    browser.tabs.remove(loginTabId);
                    loginTabId = null;
                }
                if (loginCheckInterval) {
                    clearInterval(loginCheckInterval);
                    loginCheckInterval = null;
                }

                checkBothLogins();
            } else if (response.status === 401) {
                togglStatusText.textContent = "❌ Pole veel sisse loginud Togglisse.";
            } else {
                togglStatusText.textContent = "⚠️ Tundmatu viga: " + response.status;
            }
        })
        .catch(error => {
            setLoaderVisible(false);
            togglStatusText.textContent = "⚠️ Viga Toggl API-ga: " + error.message;
        });
}
