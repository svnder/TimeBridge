import { initGithubLogin, checkBothLogins } from './auth/githubAuth.js';
import { initTogglLogin } from './auth/togglAuth.js';
import { restoreLoginStatus } from './ui/status.js';
import { setupRepoAndIssueSelection } from './ui/githubRepoIssueUI.js';
import { setupCommenting } from './ui/comment.js';

document.addEventListener('DOMContentLoaded', () => {
    restoreLoginStatus();           // Näita varasemaid staatusi (kui on)
    initGithubLogin();             // Seob GitHub login nupu
    initTogglLogin();              // Seob Toggl login nupu
    setupRepoAndIssueSelection();  // Laeb repo/issue selectid
    setupCommenting();             // Seob kommenteerimisnupu
    checkBothLogins();             // Näita õiget UI osa vastavalt login staatusele
});
